<h1 align="center">p-gen v1.0</h1>
<p align="center">
      Simple random password gnerator for Termux
</p>

## About p-gen tool :

p-gen tool is an python based script which create/generate randrom passwords in fraction of seconds. This tool works on both rooted Android device and Non-rooted Android device.

[![Build Status](https://img.shields.io/github/stars/noob-hackers/ipdrone.svg)](https://github.com/noob-hackers/ipdrone)
[![Build Status](https://img.shields.io/github/forks/noob-hackers/ipdrone.svg)](https://github.com/noob-hackers/ipdrone)
[![License: MIT](https://img.shields.io/github/license/noob-hackers/ipdrone.svg)](https://github.com/noob-hackers/ipdrone)
[![Rawsec's CyberSecurity Inventory](https://inventory.rawsec.ml/img/badges/Rawsec-inventoried-FF5050_flat.svg)](https://inventory.rawsec.ml/tools.html#p-gen)

![photo_2019-04-15_16-15-50](https://user-images.githubusercontent.com/49580304/56127910-db942700-5f9b-11e9-8450-a4fcd210cad7.jpg)

### p-gen is available for

* Termux

### Installation and usage guide
```
$ apt-get update -y
```
```
$ apt-get upgrade -y
```
```
$ pkg install python -y 
```
```
$ pkg install python2 -y
```
```
$ pkg install git -y
```
```
$ pip install requests
```
```
$ pip install random
```
```
$ ls
```
```
$ git clone https://github.com/noob-hackers/p-gen
```
```
$ ls
```
```
$ cd p-gen
```
```
$ ls
```
```
$ python p-gen.py
```
ex:- Enter The Length Of The Password: 8

WOW... you just created a strong password.

### Subscribe our channel on youtube
https://www.youtube.com/noobhackers

### Chekout our webite 
https://www.noob-hackers.com
     
### Warning

***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
